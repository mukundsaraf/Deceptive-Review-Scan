"""
review_classifier_pipeline_binary.py
=====================================
Full fake-review detection pipeline following the architecture in:
    amazon_json_domain_pipeline_builder.md

Stages
------
B  — Feature Engineering
C  — Supervised Training on cleaned_reviews.csv
D  — Semi-supervised Domain Adaptation (pseudo-labeling on Appliances.csv)
E  — Inference + thresholded output

Usage
-----
python review_classifier_pipeline_binary.py \
    --labeled   cleaned_reviews.csv \
    --unlabeled Appliances.csv \
    --output    appliances_model/

Optional inference on new CSV:
python review_classifier_pipeline_binary.py \
    --labeled   cleaned_reviews.csv \
    --unlabeled Appliances.csv \
    --infer     predict_reviews.csv \
    --output    appliances_model/
"""

import argparse
import os
import re
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
import scipy.sparse as sp

warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────

FAKE_THRESHOLD      = 0.65   # above → fake
REAL_THRESHOLD      = 0.35   # below → real
# between the two → uncertain

PSEUDO_CONFIDENCE   = 0.80   # minimum confidence for pseudo-label inclusion
MAX_PSEUDO_RATIO    = 0.40   # max fraction of training set added as pseudo-labels

TFIDF_MAX_FEATURES  = 15_000
TFIDF_NGRAM_RANGE   = (1, 2)
RANDOM_STATE        = 42


# ─────────────────────────────────────────────
# STAGE B — FEATURE ENGINEERING
# ─────────────────────────────────────────────

def build_text_column(df: pd.DataFrame) -> pd.Series:
    """Concatenate title + body for TF-IDF."""
    title = df["review_title"].fillna("").astype(str)
    text  = df["review_text"].fillna("").astype(str)
    return title + " " + text


def build_numeric_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Stage B: extract all behavioral + metadata features.
    Works for both labeled (cleaned_reviews.csv schema) and
    domain (Appliances.csv / universal schema).
    """
    feat = pd.DataFrame(index=df.index)

    text  = df["review_text"].fillna("").astype(str)
    title = df["review_title"].fillna("").astype(str)

    # ── text surface features ──────────────────────────────────────
    feat["text_len"]          = text.str.len()
    feat["word_count"]        = text.str.split().str.len().fillna(0)
    feat["title_length"]      = title.str.len()

    feat["caps_ratio"]        = text.apply(
        lambda t: sum(1 for c in t if c.isupper()) / max(len(t), 1)
    )
    feat["exclamation_count"] = text.str.count(r"!")
    feat["question_count"]    = text.str.count(r"\?")
    feat["avg_word_len"]      = text.apply(
        lambda t: np.mean([len(w) for w in t.split()] or [0])
    )

    # ── rating ─────────────────────────────────────────────────────
    feat["review_rating"]     = pd.to_numeric(df["review_rating"], errors="coerce").fillna(3)
    feat["rating_extreme"]    = feat["review_rating"].apply(lambda r: int(r in (1, 5)))
    feat["rating_5"]          = (feat["review_rating"] == 5).astype(int)
    feat["rating_1"]          = (feat["review_rating"] == 1).astype(int)

    # ── helpfulness ────────────────────────────────────────────────
    feat["helpful"]           = pd.to_numeric(
        df.get("number_of_helpful", pd.Series(0, index=df.index)),
        errors="coerce"
    ).fillna(0)
    feat["helpfulness_ratio"] = feat["helpful"] / (feat["text_len"] + 1)

    # ── photos ─────────────────────────────────────────────────────
    feat["has_photos"]        = pd.to_numeric(
        df.get("has_photos", df.get("number_of_photos", pd.Series(0, index=df.index))),
        errors="coerce"
    ).fillna(0).astype(int)

    feat["number_of_photos"]  = pd.to_numeric(
        df.get("number_of_photos", pd.Series(0, index=df.index)),
        errors="coerce"
    ).fillna(0)

    # ── campaign / verified ────────────────────────────────────────
    feat["is_campaign"]       = pd.to_numeric(
        df.get("is_campaign_product", pd.Series(0, index=df.index)),
        errors="coerce"
    ).fillna(0).astype(int)

    feat["verified_purchase"] = pd.to_numeric(
        df.get("verified_purchase", pd.Series(0, index=df.index)),
        errors="coerce"
    ).fillna(0).astype(int)

    # ── temporal ───────────────────────────────────────────────────
    feat["review_year"]       = pd.to_numeric(
        df.get("review_year", pd.Series(2019, index=df.index)),
        errors="coerce"
    ).fillna(2019)
    feat["review_month"]      = pd.to_numeric(
        df.get("review_month", pd.Series(6, index=df.index)),
        errors="coerce"
    ).fillna(6)

    # ── domain metadata (present only in Amazon JSON → CSV) ───────
    feat["image_count"]       = pd.to_numeric(
        df.get("image_count", pd.Series(0, index=df.index)),
        errors="coerce"
    ).fillna(0)
    feat["has_images"]        = (feat["image_count"] > 0).astype(int)

    feat["style_present"]     = pd.to_numeric(
        df.get("style_present", pd.Series(0, index=df.index)),
        errors="coerce"
    ).fillna(0).astype(int)

    # ── short-text flag (often spam) ──────────────────────────────
    feat["very_short_review"] = (feat["word_count"] < 5).astype(int)

    return feat.astype(float)


# ─────────────────────────────────────────────
# LABEL CONSTRUCTION
# ─────────────────────────────────────────────

def build_label(df: pd.DataFrame) -> pd.Series:
    """
    Composite fake label:
      fake_review_product OR reviewer_classified_fake OR review_is_removed_by_amazon
    Any positive signal → 1 (fake).
    """
    fake   = df["fake_review_product"].astype(bool)
    rfake  = df["reviewer_classified_fake"].astype(bool)
    removed = pd.to_numeric(
        df.get("review_is_removed_by_amazon", pd.Series(0, index=df.index)),
        errors="coerce"
    ).fillna(0).astype(bool)

    return (fake | rfake | removed).astype(int)


# ─────────────────────────────────────────────
# MODEL BUILDING
# ─────────────────────────────────────────────

class FakeReviewClassifier:
    """
    Two-component model:
      1. TF-IDF Logistic Regression (text)
      2. Logistic Regression on numeric features
    Ensemble: average soft probabilities.
    """

    def __init__(self):
        self.tfidf_pipe   = None
        self.numeric_pipe = None
        self.scaler       = StandardScaler()

    def _tfidf_pipeline(self):
        return Pipeline([
            ("tfidf", TfidfVectorizer(
                max_features  = TFIDF_MAX_FEATURES,
                ngram_range   = TFIDF_NGRAM_RANGE,
                sublinear_tf  = True,
                strip_accents = "unicode",
                min_df        = 3,
            )),
            ("clf", LogisticRegression(
                C             = 1.0,
                max_iter      = 500,
                solver        = "saga",
                class_weight  = "balanced",
                random_state  = RANDOM_STATE,
            )),
        ])

    def _numeric_lr(self):
        return LogisticRegression(
            C            = 1.0,
            max_iter     = 500,
            solver       = "saga",
            class_weight = "balanced",
            random_state = RANDOM_STATE,
        )

    def fit(self, df: pd.DataFrame, y: pd.Series):
        texts   = build_text_column(df)
        numeric = build_numeric_features(df)
        numeric_scaled = self.scaler.fit_transform(numeric)

        self.tfidf_pipe   = self._tfidf_pipeline()
        self.numeric_pipe = self._numeric_lr()

        self.tfidf_pipe.fit(texts, y)
        self.numeric_pipe.fit(numeric_scaled, y)
        return self

    def predict_proba(self, df: pd.DataFrame) -> np.ndarray:
        texts          = build_text_column(df)
        numeric        = build_numeric_features(df)
        numeric_scaled = self.scaler.transform(numeric)

        p_text    = self.tfidf_pipe.predict_proba(texts)[:, 1]
        p_numeric = self.numeric_pipe.predict_proba(numeric_scaled)[:, 1]

        # weighted ensemble: text carries 60%, numeric 40%
        return 0.60 * p_text + 0.40 * p_numeric

    def predict(self, df: pd.DataFrame, threshold: float = 0.5) -> np.ndarray:
        return (self.predict_proba(df) >= threshold).astype(int)


# ─────────────────────────────────────────────
# STAGE C — SUPERVISED TRAINING
# ─────────────────────────────────────────────

def train_supervised(labeled_path: str) -> tuple[FakeReviewClassifier, dict]:
    print("\n[Stage C] Loading labeled dataset …")
    df = pd.read_csv(labeled_path)
    print(f"          {len(df):,} rows, columns: {df.columns.tolist()}")

    y = build_label(df)
    print(f"          Label distribution — fake: {y.sum():,}  real: {(y==0).sum():,}")

    X_train, X_val, y_train, y_val = train_test_split(
        df, y, test_size=0.15, random_state=RANDOM_STATE, stratify=y
    )

    print(f"          Training on {len(X_train):,} samples …")
    clf = FakeReviewClassifier()
    clf.fit(X_train, y_train)

    # validation
    proba = clf.predict_proba(X_val)
    preds = (proba >= 0.5).astype(int)
    auc   = roc_auc_score(y_val, proba)

    print("\n[Stage C] Validation Results")
    print(f"          ROC-AUC : {auc:.4f}")
    print(classification_report(y_val, preds, target_names=["real", "fake"]))

    metrics = {"auc": auc, "val_size": len(X_val)}
    return clf, metrics


# ─────────────────────────────────────────────
# STAGE D — SEMI-SUPERVISED DOMAIN ADAPTATION
# ─────────────────────────────────────────────

def domain_adapt(
    clf_base: FakeReviewClassifier,
    labeled_path: str,
    unlabeled_path: str,
) -> FakeReviewClassifier:
    print("\n[Stage D] Loading unlabeled domain data …")
    df_domain = pd.read_csv(unlabeled_path)
    print(f"          {len(df_domain):,} rows")

    # pseudo-label
    proba        = clf_base.predict_proba(df_domain)
    pseudo_label = (proba >= 0.5).astype(int)
    confident    = (proba >= PSEUDO_CONFIDENCE) | (proba <= (1 - PSEUDO_CONFIDENCE))

    df_pseudo        = df_domain[confident].copy()
    df_pseudo["_y"]  = pseudo_label[confident]

    # cap pseudo-label volume
    df_labeled = pd.read_csv(labeled_path)
    max_pseudo = int(len(df_labeled) * MAX_PSEUDO_RATIO)
    if len(df_pseudo) > max_pseudo:
        df_pseudo = df_pseudo.sample(max_pseudo, random_state=RANDOM_STATE)

    print(f"          Pseudo-labels accepted: {len(df_pseudo):,}  "
          f"(conf ≥ {PSEUDO_CONFIDENCE}, capped at {MAX_PSEUDO_RATIO:.0%} of labeled)")

    # ── align schemas before concat ───────────────────────────────
    y_labeled  = build_label(df_labeled)
    df_labeled = df_labeled.copy()
    df_labeled["_y"] = y_labeled
    df_pseudo["_y"]  = df_pseudo["_y"]   # already set above

    # find common feature columns (excluding _y)
    shared_cols = [c for c in df_labeled.columns if c in df_pseudo.columns and c != "_y"]
    shared_cols_with_y = shared_cols + ["_y"]

    df_combined = pd.concat(
        [df_labeled[shared_cols_with_y], df_pseudo[shared_cols_with_y]],
        ignore_index=True
    )
    y_combined  = df_combined.pop("_y")

    print(f"          Combined training size: {len(df_combined):,}")

    clf_adapted = FakeReviewClassifier()
    clf_adapted.fit(df_combined, y_combined)
    print("[Stage D] Domain-adapted model trained.")
    return clf_adapted


# ─────────────────────────────────────────────
# STAGE E — INFERENCE
# ─────────────────────────────────────────────

def infer(clf: FakeReviewClassifier, infer_path: str, output_dir: str):
    print(f"\n[Stage E] Running inference on: {infer_path}")
    df    = pd.read_csv(infer_path)
    proba = clf.predict_proba(df)

    # hard labels with uncertainty band
    hard = np.where(
        proba >= FAKE_THRESHOLD, "fake",
        np.where(proba <= REAL_THRESHOLD, "real", "uncertain")
    )

    df_soft       = df.copy()
    df_soft["fake_probability"] = proba
    df_soft["prediction_soft"]  = hard

    df_hard       = df.copy()
    df_hard["fake_label"]       = (proba >= 0.5).astype(int)
    df_hard["confidence"]       = np.where(proba >= 0.5, proba, 1 - proba)

    soft_path = Path(output_dir) / "inference_results_soft.csv"
    hard_path = Path(output_dir) / "inference_results_hard.csv"

    df_soft.to_csv(soft_path, index=False)
    df_hard.to_csv(hard_path, index=False)

    print(f"[Stage E] Soft predictions → {soft_path}")
    print(f"[Stage E] Hard predictions → {hard_path}")
    print(f"\n          Distribution:")
    for label, count in pd.Series(hard).value_counts().items():
        print(f"            {label:>10s}: {count:,}  ({count/len(hard)*100:.1f}%)")


# ─────────────────────────────────────────────
# DOMAIN EVALUATION UTILITY
# ─────────────────────────────────────────────

def _print_banner(title: str):
    width = 60
    print("\n" + "═" * width)
    print(f"  {title}")
    print("═" * width)


def _distribution_report(proba: np.ndarray, label: str):
    hard = np.where(
        proba >= FAKE_THRESHOLD, "fake",
        np.where(proba <= REAL_THRESHOLD, "real", "uncertain")
    )
    counts = pd.Series(hard).value_counts()
    total  = len(hard)
    print(f"\n  [{label}] Prediction Distribution  (n={total:,})")
    print(f"  {'Label':<12} {'Count':>8}  {'%':>6}")
    print(f"  {'-'*30}")
    for lbl in ["fake", "uncertain", "real"]:
        c = counts.get(lbl, 0)
        print(f"  {lbl:<12} {c:>8,}  {c/total*100:>5.1f}%")
    print(f"\n  Avg fake probability : {proba.mean():.4f}")
    print(f"  Median fake prob     : {np.median(proba):.4f}")
    print(f"  Std dev              : {proba.std():.4f}")
    return hard


def evaluate_on_domain(
    clf_base:    FakeReviewClassifier,
    clf_adapted: FakeReviewClassifier,
    domain_path: str,
    output_dir:  str,
):
    """
    Run BOTH the foundational model and the domain-adapted model on the
    domain CSV and print a side-by-side comparison.

    Because the domain data is unlabeled we cannot compute precision/recall
    against ground truth — instead we report:
      • prediction distribution (fake / uncertain / real)
      • probability statistics
      • agreement rate between the two models
      • confidence histogram buckets
    """
    _print_banner("DOMAIN DATA EVALUATION")
    print(f"  File: {domain_path}")

    df = pd.read_csv(domain_path)
    print(f"  Rows: {len(df):,}\n")

    # ── foundational model ────────────────────────────────────────
    _print_banner("Foundational Model (Stage C) — on Domain Data")
    p_base = clf_base.predict_proba(df)
    hard_base = _distribution_report(p_base, "Foundational")

    # ── adapted model ─────────────────────────────────────────────
    _print_banner("Domain-Adapted Model (Stage D) — on Domain Data")
    p_adapted = clf_adapted.predict_proba(df)
    hard_adapted = _distribution_report(p_adapted, "Adapted")

    # ── model agreement ───────────────────────────────────────────
    _print_banner("Model Agreement")
    agree     = (hard_base == hard_adapted).sum()
    disagree  = len(hard_base) - agree
    print(f"\n  Agree    : {agree:,}  ({agree/len(hard_base)*100:.1f}%)")
    print(f"  Disagree : {disagree:,}  ({disagree/len(hard_base)*100:.1f}%)")

    shift_to_fake = ((hard_base != "fake") & (hard_adapted == "fake")).sum()
    shift_to_real = ((hard_base != "real") & (hard_adapted == "real")).sum()
    print(f"\n  Adaptation shifted → fake : {shift_to_fake:,}")
    print(f"  Adaptation shifted → real : {shift_to_real:,}")

    delta = p_adapted - p_base
    print(f"\n  Avg probability shift (adapted − base): {delta.mean():+.4f}")
    print(f"  (positive = adapted model more suspicious of fakes)")

    # ── confidence buckets ────────────────────────────────────────
    _print_banner("Confidence Buckets — Adapted Model")
    buckets = [0.0, 0.2, 0.4, 0.6, 0.8, 1.01]
    labels  = ["0.0–0.2 (strong real)", "0.2–0.4 (lean real)",
               "0.4–0.6 (uncertain)",  "0.6–0.8 (lean fake)",
               "0.8–1.0 (strong fake)"]
    print(f"\n  {'Bucket':<26} {'Count':>8}  {'%':>6}")
    print(f"  {'-'*42}")
    for i, lbl in enumerate(labels):
        mask = (p_adapted >= buckets[i]) & (p_adapted < buckets[i+1])
        c = mask.sum()
        print(f"  {lbl:<26} {c:>8,}  {c/len(p_adapted)*100:>5.1f}%")

    # ── save outputs ──────────────────────────────────────────────
    domain_name = Path(domain_path).stem
    out_path = Path(output_dir) / f"{domain_name}_predictions.csv"

    df_out = df.copy()
    df_out["base_fake_probability"]    = p_base
    df_out["adapted_fake_probability"] = p_adapted
    df_out["base_prediction"]          = hard_base
    df_out["adapted_prediction"]       = hard_adapted
    df_out["models_agree"]             = (hard_base == hard_adapted).astype(int)
    df_out.to_csv(out_path, index=False)

    print(f"\n  ✅  Saved predictions → {out_path}")
    print("═" * 60)


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Fake Review Detection Pipeline")
    parser.add_argument("--labeled",   required=True,  help="Path to cleaned_reviews.csv")
    parser.add_argument("--unlabeled", required=True,  help="Path to Appliances.csv")
    parser.add_argument("--infer",     default=None,   help="Optional: CSV for inference")
    parser.add_argument("--output",    default="output/", help="Output directory")
    parser.add_argument("--sample",    type=int, default=None,
                        help="Max rows to sample from labeled data (default: all)")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    # Stage C — supervised training
    clf_base, metrics = train_supervised(args.labeled)

    # Stage D — domain adaptation
    clf_adapted = domain_adapt(clf_base, args.labeled, args.unlabeled)

    # Stage E — side-by-side domain evaluation (base vs adapted)
    evaluate_on_domain(clf_base, clf_adapted, args.unlabeled, args.output)

    # Stage E — optional inference on separate prediction CSV
    if args.infer:
        infer(clf_adapted, args.infer, args.output)

    print(f"\n✅  Pipeline complete. Outputs in: {args.output}")


if __name__ == "__main__":
    main()
